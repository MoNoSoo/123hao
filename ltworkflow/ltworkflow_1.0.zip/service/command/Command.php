<?php 
interface Command{
	public function execute();
}