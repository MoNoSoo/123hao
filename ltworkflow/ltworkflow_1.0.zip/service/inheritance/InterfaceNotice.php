<?php
/**
 * 
 * 通知用户信息接口
 * @author liutao
 *
 */
interface InterfaceNotice {
	
	function noticeNextUser();
}