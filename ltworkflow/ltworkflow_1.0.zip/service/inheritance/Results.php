<?php
//定义条件类模板
abstract class Results extends WorkflowBase{
   
   abstract function validate();

}