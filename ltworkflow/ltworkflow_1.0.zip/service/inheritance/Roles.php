<?php
//定义角色类模板
abstract class Roles extends WorkflowBase{
  
   
   abstract function getUserRole();

}