<?php
/**
 * 
 * 驳回接口
 * @author liutao
 *
 */
interface  InterfaceReject {
	
	function reject_entry($etuid);

}