<?php
//定义流程后处理模板
abstract class Func extends WorkflowBase{
  
  abstract function validate();
}