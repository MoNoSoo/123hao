<?php
/**
 * 
 * 用户初始化
 * @author liutao
 *
 */
interface  InterfaceInit {
	
	function init_entry();

}