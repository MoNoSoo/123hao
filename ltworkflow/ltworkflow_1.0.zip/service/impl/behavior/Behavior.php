<?php 
interface Behavior{
	public function execute();
}