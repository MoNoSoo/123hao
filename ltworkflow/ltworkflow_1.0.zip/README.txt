ltworkflow 1.0
===========
Copyright 2016-2017 liutao,http://phpworkflow.cn

ltworkflow 是轻量级PHP工作流引擎，需要嵌入到已有项目中使用,本项目遵循开源协议 Apache License V2。

It's open-source and distributed under the Apache license Version 2.0. 