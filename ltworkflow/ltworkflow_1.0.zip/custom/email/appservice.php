<?php
class AppService implements InterfaceNotice{
	/*
	 * 向手机应用推送代办
	 *
	 */
	function noticeNextUser() {
		
		
	}
	
	
}
