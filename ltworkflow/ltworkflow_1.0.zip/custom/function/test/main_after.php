<?php
/*
 * 主流程审批节点后处理
 */
class main_after extends WorkflowBase {
	
	function main_after() {
	
	}
	
	function validate() {
		
		return true;
	}

}

