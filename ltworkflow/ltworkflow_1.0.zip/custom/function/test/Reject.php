<?php
/*
 *  
 */
class Reject extends WorkflowBase {
	
	/**
	 * 驳回时操作
	 *
	 */
	function reject_entry($etuid) {
		
	}
	/**
	 * 驳回时操作
	 *
	 */
	function reject_dapian($etuid) {
		
	}
}