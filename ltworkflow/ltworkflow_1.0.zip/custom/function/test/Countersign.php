<?php

class Countersign extends WorkflowBase{

  /**
   * 会签到起草人时校验
   *
   */
  function check_countersign($etuid){

  }
	/**
	 * 起草人送审后处理
	 *
	 * @param unknown_type $etuid
	 */
	function on_countersign($etuid){

	}
}